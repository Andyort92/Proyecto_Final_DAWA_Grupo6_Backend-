﻿using Entidades.Entidades;
using Entidades.Repositorios;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ProyectoWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly iRepositorioCliente _repositorioCliente;

        public ClienteController (iRepositorioCliente repositorioCliente)
        {
            _repositorioCliente = repositorioCliente;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var listCliente = await _repositorioCliente.ObtenerTodos();
                return Ok(listCliente);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var Cliente = await _repositorioCliente.ObtenerPorId(id);
            if (Cliente == null)
            {
                return NotFound();
            }
            return Ok(Cliente);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Cliente cliente)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _repositorioCliente.Agregar(cliente);
                return CreatedAtAction(nameof(Get), new { id = cliente.Id }, cliente);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Cliente clienteActualizado)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != clienteActualizado.Id)
            {
                return BadRequest("El ID de la URL no coincide con el ID del objeto");
            }

            try
            {
                await _repositorioCliente.Actualizar(clienteActualizado);
                return NoContent();
            }
            catch (DbUpdateException dbEx)
            {
                // Extraer información detallada de la excepción
                var errorMessage = dbEx.InnerException?.Message ?? dbEx.Message;

                // Aquí puedes registrar el error o lanzar una excepción personalizada
                // Logger.LogError(dbEx, "Error al actualizar la persona");

                return StatusCode(500, "Error al actualizar la persona. Detalles: " + errorMessage);
            }
            catch (Exception ex)
            {
                // Aquí puedes registrar el error o lanzar una excepción personalizada
                // Logger.LogError(ex, "Error desconocido al actualizar la persona");

                return StatusCode(500, "Error desconocido al actualizar la persona");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var cliente = await _repositorioCliente.Eliminar(id);
                if (cliente == null)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }


    }
}
