﻿using Entidades.Repositorios;
using Entidades.Entidades;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ProyectoWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VueloController : ControllerBase
    {
        private readonly iRepositorioVuelo _repositorioVuelo;

        public VueloController(iRepositorioVuelo repositorioVuelo)
        {
            _repositorioVuelo = repositorioVuelo;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var listVuelo = await _repositorioVuelo.ObtenerTodos();
                return Ok(listVuelo);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var Vuelo = await _repositorioVuelo.ObtenerPorId(id);
            if (Vuelo == null)
            {
                return NotFound();
            }
            return Ok(Vuelo);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Vuelo vuelo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _repositorioVuelo.Agregar(vuelo);
                return CreatedAtAction(nameof(Get), new { id = vuelo.Id }, vuelo);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Vuelo vueloActualizado)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != vueloActualizado.Id)
            {
                return BadRequest("El ID de la URL no coincide con el ID del objeto");
            }

            try
            {
                await _repositorioVuelo.Actualizar(vueloActualizado);
                return NoContent();
            }
            catch (DbUpdateException dbEx)
            {
                // Extraer información detallada de la excepción
                var errorMessage = dbEx.InnerException?.Message ?? dbEx.Message;

                // Aquí puedes registrar el error o lanzar una excepción personalizada
                // Logger.LogError(dbEx, "Error al actualizar la persona");

                return StatusCode(500, "Error al actualizar la persona. Detalles: " + errorMessage);
            }
            catch (Exception ex)
            {
                // Aquí puedes registrar el error o lanzar una excepción personalizada
                // Logger.LogError(ex, "Error desconocido al actualizar la persona");

                return StatusCode(500, "Error desconocido al actualizar la persona");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var vuelo = await _repositorioVuelo.Eliminar(id);
                if (vuelo == null)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
