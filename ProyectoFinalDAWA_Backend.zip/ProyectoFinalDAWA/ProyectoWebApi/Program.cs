
using Entidades.Entidades;
using Entidades.Repositorios;
using Microsoft.EntityFrameworkCore;

namespace ProyectoWebApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<ApplicationDbContext>(optiones => optiones.UseSqlServer("name=DefaultConnection"));

            // Add services to the container.

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddScoped<iRepositorioCliente, RepositorioCliente>();
            builder.Services.AddScoped<iRepositorioVuelo, RepositorioVuelo>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}