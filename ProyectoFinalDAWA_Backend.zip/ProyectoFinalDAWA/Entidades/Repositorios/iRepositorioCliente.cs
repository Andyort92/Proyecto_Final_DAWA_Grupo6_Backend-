﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Entidades;

namespace Entidades.Repositorios
{
    public interface iRepositorioCliente
    {
        Task<List<Cliente>> ObtenerTodos();

        Task<int> Agregar(Cliente cliente);

        Task<int> Actualizar(Cliente cliente);

        Task<Cliente?> Eliminar(int id);

        Task<Cliente?> ObtenerPorId(int id);

    }
}
