﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Entidades;
using Microsoft.EntityFrameworkCore;

namespace Entidades.Repositorios
{
    public class RepositorioCliente : iRepositorioCliente
    {
        private readonly ApplicationDbContext context;

        public RepositorioCliente (ApplicationDbContext context)
        {
            this.context = context;
        }


        public async Task<int> Actualizar(Cliente cliente)
        {
            context.clientes.Update(cliente);
            await context.SaveChangesAsync();
            return cliente.Id;
        }

        public async Task<int> Agregar(Cliente cliente)
        {

                try
                {
                    context.clientes.Add(cliente);
                    await context.SaveChangesAsync();
                    return cliente.Id;
                }
                catch (DbUpdateException dbEx)
                {
                    // Extraer información detallada de la excepción
                    var errorMessage = dbEx.InnerException?.Message ?? dbEx.Message;

                    // Aquí puedes registrar el error o lanzar una excepción personalizada
                    // Logger.LogError(dbEx, "Error al agregar la persona");

                    throw new InvalidOperationException("Error al agregar la persona. Detalles: " + errorMessage, dbEx);
                }
                catch (Exception ex)
                {
                    // Aquí puedes registrar el error o lanzar una excepción personalizada
                    // Logger.LogError(ex, "Error desconocido al agregar la persona");

                    throw new InvalidOperationException("Error desconocido al agregar la persona", ex);
                }
            
        }

        public async Task<Cliente?> Eliminar(int id)
        {
            var cliente = await context.clientes.FindAsync(id);
            if (cliente != null)
            {
                context.clientes.Remove(cliente);
                await context.SaveChangesAsync();
            }
            return cliente;
        }

        public async Task<Cliente?> ObtenerPorId(int id)
        {
            return await context.clientes.FindAsync(id);
        }

        public async Task<List<Cliente>> ObtenerTodos()
        {
            return await context.clientes.ToListAsync();
        }
    }
}
