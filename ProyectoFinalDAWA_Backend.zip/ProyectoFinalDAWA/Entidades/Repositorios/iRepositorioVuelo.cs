﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Entidades;

namespace Entidades.Repositorios
{
    public interface iRepositorioVuelo
    {

        Task<List<Vuelo>> ObtenerTodos();

        Task<int> Agregar(Vuelo vuelo);

        Task<int> Actualizar(Vuelo vuelo);

        Task<Vuelo?> Eliminar(int id);

        Task<Vuelo?> ObtenerPorId(int id);

    }
}
