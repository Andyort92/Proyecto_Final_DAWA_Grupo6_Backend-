﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Entidades;
using Microsoft.EntityFrameworkCore;

namespace Entidades.Repositorios
{
    public class RepositorioVuelo : iRepositorioVuelo
    {
        private readonly ApplicationDbContext context;

        public RepositorioVuelo (ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<int> Actualizar(Vuelo vuelo)
        {
            context.vuelos.Update(vuelo);
            await context.SaveChangesAsync();
            return vuelo.Id;
        }

        public async Task<int> Agregar(Vuelo vuelo)
        {
            try
            {
                context.vuelos.Add(vuelo);
                await context.SaveChangesAsync();
                return vuelo.Id;
            }
            catch (DbUpdateException dbEx)
            {
                // Extraer información detallada de la excepción
                var errorMessage = dbEx.InnerException?.Message ?? dbEx.Message;

                // Aquí puedes registrar el error o lanzar una excepción personalizada
                // Logger.LogError(dbEx, "Error al agregar la persona");

                throw new InvalidOperationException("Error al agregar la persona. Detalles: " + errorMessage, dbEx);
            }
            catch (Exception ex)
            {
                // Aquí puedes registrar el error o lanzar una excepción personalizada
                // Logger.LogError(ex, "Error desconocido al agregar la persona");

                throw new InvalidOperationException("Error desconocido al agregar la persona", ex);
            }
        }

        public async Task<Vuelo?> Eliminar(int id)
        {
            var vuelo = await context.vuelos.FindAsync(id);
            if (vuelo != null)
            {
                context.vuelos.Remove(vuelo);
                await context.SaveChangesAsync();
            }
            return vuelo;
        }

        public async Task<Vuelo?> ObtenerPorId(int id)
        {
            return await context.vuelos.FindAsync(id);
        }

        public async Task<List<Vuelo>> ObtenerTodos()
        {
            return await context.vuelos.ToListAsync();
        }
    }
}
