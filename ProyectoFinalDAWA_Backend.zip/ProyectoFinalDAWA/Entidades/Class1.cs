﻿namespace Entidades
{
    public class Class1
    {

    }
}