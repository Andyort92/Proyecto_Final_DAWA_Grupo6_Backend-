﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Entidades
{
    public class Vuelo
    {
        public int Id { get; set; }
        public string Destino { get; set; } = null!;
        public string NombreAerolinea { get; set; } = null!;
        public DateTime FechaDePartida { get; set; }
        public DateTime FechaLLegada { get; set; }
        public int NumeroDeVuelo { get; set; }
        public string TipoDeVuelo { get; set; } = null!;


    }
}
