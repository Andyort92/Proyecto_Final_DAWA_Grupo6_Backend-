﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Entidades.Entidades
{
    public class ApplicationDbContext : DbContext
    {
         public ApplicationDbContext(DbContextOptions options) : base(options) { }
      /*
          protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
           {
               optionsBuilder.UseSqlServer(@"Server=DESKTOP-Q2FMGEB\LOCALHOST;Database=ProyectoDawa;Integrated Security=True;TrustServerCertificate=True;");

           }
      */
        public DbSet<Cliente> clientes { get; set; }
        public DbSet<Vuelo> vuelos { get; set; }




    }
}
